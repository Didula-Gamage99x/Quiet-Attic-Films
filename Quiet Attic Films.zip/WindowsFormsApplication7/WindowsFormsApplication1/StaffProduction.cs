﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class StaffProduction : Form
    {
        String con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\quite attic films system\WindowsFormsApplication7\WindowsFormsApplication1\Database2.mdf;Integrated Security=True";
        public StaffProduction()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void StaffProduction_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();

                SqlCommand mycmd = new SqlCommand("select Production_ID from Production", con);
                SqlDataReader r = mycmd.ExecuteReader();

                while (r.Read())
                {
                    comboBoxpdid.Items.Add(r["Production_ID"].ToString());
                }
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error" + ee.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
           
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
           
        }

        private void btndel_Click(object sender, EventArgs e)
        {
           
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
           
        }

        private void btninsert_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("insert into Staff_Production(Production_ID,Camera_Crew,Producer,Runner,Actor,Voice_Actor ) values(@Production_ID,@Camera_Crew,@Producer,@Runner,@Actor,@Voice_Actor)", con);
                mycmd.Parameters.AddWithValue("@Production_ID", comboBoxpdid.SelectedItem.ToString());

                mycmd.Parameters.AddWithValue("@Camera_Crew", txtcameracrew.Text);
                mycmd.Parameters.AddWithValue("@Runner", txtrunner.Text);
                mycmd.Parameters.AddWithValue("@Producer", txtproducer.Text);
                mycmd.Parameters.AddWithValue("@Actor", txtactor.Text);
                mycmd.Parameters.AddWithValue("@Voice_Actor", txtvoiceactor.Text);


                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("update Staff_Production set Staff_ID=@Staff_ID,Camera_Crew=@Camera_Crew,Runner=@Runner,Producer=@Producer,Actor=@Actor,Voice_Actor=@Voice_Actor where Production_ID=@Production_ID", con);
                mycmd.Parameters.AddWithValue("@Production_ID", comboBoxpdid.SelectedItem.ToString());

                mycmd.Parameters.AddWithValue("@Camera_Crew", txtcameracrew.Text);
                mycmd.Parameters.AddWithValue("@Runner", txtrunner.Text);
                mycmd.Parameters.AddWithValue("@Producer", txtproducer.Text);
                mycmd.Parameters.AddWithValue("@Actor", txtactor.Text);
                mycmd.Parameters.AddWithValue("@Voice_Actor", txtvoiceactor.Text);
                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btndel_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("delete from Staff_Production where Production_ID=@Production_ID  and Camera_Crew=@Camera_Crew and Runner=@Runner and Producer=@Producer and Actor=@Actor and Voice_Actor=@Voice_Actor", con);
                mycmd.Parameters.AddWithValue("@Production_ID", comboBoxpdid.SelectedItem.ToString());

                mycmd.Parameters.AddWithValue("@Camera_Crew", txtcameracrew.Text);
                mycmd.Parameters.AddWithValue("@Runner", txtrunner.Text);
                mycmd.Parameters.AddWithValue("@Producer", txtproducer.Text);
                mycmd.Parameters.AddWithValue("@Actor", txtactor.Text);
                mycmd.Parameters.AddWithValue("@Voice_Actor", txtvoiceactor.Text);
                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Succesfully deleted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Can not delete" + ee.Message);
            }
        }

        private void btnsearch_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("select * from Staff_Production", con);

                SqlDataAdapter ad = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error");

            }
        }
    }
}
