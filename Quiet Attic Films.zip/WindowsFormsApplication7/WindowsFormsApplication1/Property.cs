﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Property : Form
    {
        String con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\quite attic films system\WindowsFormsApplication7\WindowsFormsApplication1\Database2.mdf;Integrated Security=True";
        public Property()
        {
            InitializeComponent();
        }

        private void Property_Load(object sender, EventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("insert into Property(Property_ID,Property_Name,Property_type) values (@Property_ID,@Property_Name,@Property_type)", con);
                mycmd.Parameters.AddWithValue("@Property_ID", txtpropertyid.Text);
                mycmd.Parameters.AddWithValue("@Property_Name", txtpropertyname.Text);
                mycmd.Parameters.AddWithValue("@Property_type", txtpropertytype.Text);


                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("update Property set Property_Name=@Property_Name,Property_type=@Property_type where Property_ID=@Property_ID", con);
                mycmd.Parameters.AddWithValue("@Property_ID", txtpropertyid.Text);
                mycmd.Parameters.AddWithValue("@Property_Name", txtpropertyname.Text);
                mycmd.Parameters.AddWithValue("@Property_type", txtpropertytype.Text);

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("delete from Property where Property_ID=@Property_ID", con);
                mycmd.Parameters.AddWithValue("@Property_ID", txtpropertyid.Text);
                mycmd.Parameters.AddWithValue("@Property_Name", txtpropertyname.Text);
                mycmd.Parameters.AddWithValue("@property_type", txtpropertytype.Text);

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Succesfully deleted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Can not delete" + ee.Message);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("select * from Property", con);

                SqlDataAdapter ad = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error");

            }
        }
    }
}
