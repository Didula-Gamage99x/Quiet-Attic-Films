﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnlgn_Click(object sender, EventArgs e)
        {
            if (txtusr.Text == "Didula" && txtpwd.Text == "123")
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect User Name or Password");
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                Application.Exit();
            }
        }
    }
}
