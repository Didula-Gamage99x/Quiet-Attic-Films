﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
        }

        private void btnclient_Click(object sender, EventArgs e)
        {
            {
                Client frm = new Client();
                frm.Show();
                this.Hide();
            }
        }

        private void btnproduction_Click(object sender, EventArgs e)
        {
            {
                Production frm = new Production();
                frm.Show();
                this.Hide();
            }
        }

        private void btnlocation_Click(object sender, EventArgs e)
        {
            {
                Location frm = new Location();
                frm.Show();
                this.Hide();
            }
        }

        private void btnproperty_Click(object sender, EventArgs e)
        {
            {
                Property frm = new Property();
                frm.Show();
                this.Hide();
            }
        }

        private void btnstaff_Click(object sender, EventArgs e)
        {
            {
                Staff frm = new Staff();
                frm.Show();
                this.Hide();
            }
        }

        private void btnproductionstaff_Click(object sender, EventArgs e)
        {
            {
                StaffProduction frm = new StaffProduction();
                frm.Show();
                this.Hide();
            }
        }

        private void txtpropertyproduction_Click(object sender, EventArgs e)
        {
            {
                PropertyProduction frm = new PropertyProduction();
                frm.Show();
                this.Hide();
            }
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
