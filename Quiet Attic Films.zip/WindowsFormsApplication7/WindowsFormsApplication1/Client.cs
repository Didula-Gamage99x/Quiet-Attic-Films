﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Client : Form
    {
        String con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\quite attic films system\WindowsFormsApplication7\WindowsFormsApplication1\Database2.mdf;Integrated Security=True";
        public Client()
        {
            InitializeComponent();
        }

        private void Client_Load(object sender, EventArgs e)
        {

        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("insert into Client(Client_ID,Client_Name,Contact,Address) values(@Client_ID,@Client_Name,@Contact,@Address)", con);
                mycmd.Parameters.AddWithValue("@Client_ID", txtclient.Text);
                mycmd.Parameters.AddWithValue("@Client_Name", txtclientname.Text);
                mycmd.Parameters.AddWithValue("@Contact", txtcontact.Text);
                mycmd.Parameters.AddWithValue("@Address", txtaddress.Text);

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong"+ ee.Message);
            }

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("update Client set Client_Name=@Client_Name,Contact=@Contact,Address=@Address where Client_ID=@Client_ID", con);
                mycmd.Parameters.AddWithValue("@Client_ID", txtclient.Text);
                mycmd.Parameters.AddWithValue("@Client_Name", txtclientname.Text);
                mycmd.Parameters.AddWithValue("@Contact", txtcontact.Text);
                mycmd.Parameters.AddWithValue("@Address", txtaddress.Text);

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong"+ ee.Message);
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("delete from Client where Client_ID=@Client_ID", con);
                mycmd.Parameters.AddWithValue("@Client_ID", txtclient.Text);
                mycmd.Parameters.AddWithValue("@Client_Name", txtclientname.Text);
                mycmd.Parameters.AddWithValue("@Contact", txtcontact.Text);
                mycmd.Parameters.AddWithValue("@Address", txtaddress.Text);

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Succesfully deleted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Can not delete" + ee.Message);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("select * from Client", con);

                SqlDataAdapter ad = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error");

            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
