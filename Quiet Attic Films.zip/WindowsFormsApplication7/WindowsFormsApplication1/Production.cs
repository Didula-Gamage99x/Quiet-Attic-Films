﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Production : Form
    {
        String con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\quite attic films system\WindowsFormsApplication7\WindowsFormsApplication1\Database2.mdf;Integrated Security=True";
        
        public Production()
        {
            InitializeComponent();
        }

        private void Production_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();

                SqlCommand mycmd = new SqlCommand("select Client_ID from CLient", con);
                SqlDataReader r = mycmd.ExecuteReader();

                while (r.Read())
                {
                    comboBoxcid.Items.Add(r["Client_ID"].ToString());
                }
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error" + ee.Message);
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("insert into Production(Production_ID,Production_Type,Client_ID)values(@Production_ID,@Production_Type,@Client_ID)", con);
                mycmd.Parameters.AddWithValue("@Production_ID", txtproductionid.Text);
                mycmd.Parameters.AddWithValue("@Production_Type", txtproductiontype.Text);
                mycmd.Parameters.AddWithValue("@Client_ID", comboBoxcid.SelectedItem.ToString());
              


                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("update production set Production_Type=@Production_Type,Client_ID=@Client_ID where Production_ID=@Production_ID", con);
                mycmd.Parameters.AddWithValue("@Production_ID", txtproductionid.Text);
                mycmd.Parameters.AddWithValue("@Production_Type", txtproductiontype.Text);
                mycmd.Parameters.AddWithValue("@Client_ID", comboBoxcid.SelectedItem.ToString());



                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("delete from Production where Production_ID=@Production_ID", con);
                mycmd.Parameters.AddWithValue("@Production_ID", txtproductionid.Text);
                mycmd.Parameters.AddWithValue("@Production_Type", txtproductiontype.Text);
                mycmd.Parameters.AddWithValue("@Client_ID", comboBoxcid.SelectedItem.ToString());


                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Succesfully deleted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Can not delete" + ee.Message);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("select * from Production", con);

                SqlDataAdapter ad = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error");

            }
        }

        private void comboBoxcid_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void txtproductionid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
