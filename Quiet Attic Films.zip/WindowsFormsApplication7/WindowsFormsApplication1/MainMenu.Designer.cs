﻿namespace WindowsFormsApplication1
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnclient = new System.Windows.Forms.Button();
            this.btnproduction = new System.Windows.Forms.Button();
            this.btnlocation = new System.Windows.Forms.Button();
            this.btnproperty = new System.Windows.Forms.Button();
            this.btnstaff = new System.Windows.Forms.Button();
            this.btnproductionstaff = new System.Windows.Forms.Button();
            this.txtpropertyproduction = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnclient
            // 
            this.btnclient.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnclient.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclient.Location = new System.Drawing.Point(159, 132);
            this.btnclient.Name = "btnclient";
            this.btnclient.Size = new System.Drawing.Size(246, 40);
            this.btnclient.TabIndex = 1;
            this.btnclient.Text = "Client";
            this.btnclient.UseVisualStyleBackColor = false;
            this.btnclient.Click += new System.EventHandler(this.btnclient_Click);
            // 
            // btnproduction
            // 
            this.btnproduction.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnproduction.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnproduction.Location = new System.Drawing.Point(304, 205);
            this.btnproduction.Name = "btnproduction";
            this.btnproduction.Size = new System.Drawing.Size(246, 40);
            this.btnproduction.TabIndex = 2;
            this.btnproduction.Text = "Production";
            this.btnproduction.UseVisualStyleBackColor = false;
            this.btnproduction.Click += new System.EventHandler(this.btnproduction_Click);
            // 
            // btnlocation
            // 
            this.btnlocation.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnlocation.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlocation.Location = new System.Drawing.Point(159, 292);
            this.btnlocation.Name = "btnlocation";
            this.btnlocation.Size = new System.Drawing.Size(246, 40);
            this.btnlocation.TabIndex = 3;
            this.btnlocation.Text = "Location";
            this.btnlocation.UseVisualStyleBackColor = false;
            this.btnlocation.Click += new System.EventHandler(this.btnlocation_Click);
            // 
            // btnproperty
            // 
            this.btnproperty.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnproperty.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnproperty.Location = new System.Drawing.Point(304, 381);
            this.btnproperty.Name = "btnproperty";
            this.btnproperty.Size = new System.Drawing.Size(246, 40);
            this.btnproperty.TabIndex = 4;
            this.btnproperty.Text = "Property";
            this.btnproperty.UseVisualStyleBackColor = false;
            this.btnproperty.Click += new System.EventHandler(this.btnproperty_Click);
            // 
            // btnstaff
            // 
            this.btnstaff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnstaff.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstaff.Location = new System.Drawing.Point(159, 466);
            this.btnstaff.Name = "btnstaff";
            this.btnstaff.Size = new System.Drawing.Size(246, 40);
            this.btnstaff.TabIndex = 5;
            this.btnstaff.Text = "Staff";
            this.btnstaff.UseVisualStyleBackColor = false;
            this.btnstaff.Click += new System.EventHandler(this.btnstaff_Click);
            // 
            // btnproductionstaff
            // 
            this.btnproductionstaff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnproductionstaff.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnproductionstaff.Location = new System.Drawing.Point(304, 545);
            this.btnproductionstaff.Name = "btnproductionstaff";
            this.btnproductionstaff.Size = new System.Drawing.Size(246, 40);
            this.btnproductionstaff.TabIndex = 6;
            this.btnproductionstaff.Text = "Staff Production";
            this.btnproductionstaff.UseVisualStyleBackColor = false;
            this.btnproductionstaff.Click += new System.EventHandler(this.btnproductionstaff_Click);
            // 
            // txtpropertyproduction
            // 
            this.txtpropertyproduction.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtpropertyproduction.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpropertyproduction.Location = new System.Drawing.Point(159, 628);
            this.txtpropertyproduction.Name = "txtpropertyproduction";
            this.txtpropertyproduction.Size = new System.Drawing.Size(246, 40);
            this.txtpropertyproduction.TabIndex = 7;
            this.txtpropertyproduction.Text = "Property Production";
            this.txtpropertyproduction.UseVisualStyleBackColor = false;
            this.txtpropertyproduction.Click += new System.EventHandler(this.txtpropertyproduction_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Red;
            this.btnback.Font = new System.Drawing.Font("Perpetua Titling MT", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.White;
            this.btnback.Location = new System.Drawing.Point(575, 727);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(123, 35);
            this.btnback.TabIndex = 0;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(198, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 52);
            this.label1.TabIndex = 8;
            this.label1.Text = "MAIN MENU";
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.gettyimages_1244034031_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(710, 774);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtpropertyproduction);
            this.Controls.Add(this.btnproductionstaff);
            this.Controls.Add(this.btnstaff);
            this.Controls.Add(this.btnproperty);
            this.Controls.Add(this.btnlocation);
            this.Controls.Add(this.btnproduction);
            this.Controls.Add(this.btnclient);
            this.Controls.Add(this.btnback);
            this.Name = "MainMenu";
            this.Text = "MainMenu";
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnclient;
        private System.Windows.Forms.Button btnproduction;
        private System.Windows.Forms.Button btnlocation;
        private System.Windows.Forms.Button btnproperty;
        private System.Windows.Forms.Button btnstaff;
        private System.Windows.Forms.Button btnproductionstaff;
        private System.Windows.Forms.Button txtpropertyproduction;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Label label1;
    }
}