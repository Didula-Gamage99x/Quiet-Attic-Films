﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Staff : Form
    {
        String con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\quite attic films system\WindowsFormsApplication7\WindowsFormsApplication1\Database2.mdf;Integrated Security=True";
        public Staff()
        {
            InitializeComponent();
        }

        private void Staff_Load(object sender, EventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("insert into Staff(Staff_ID,Staff_Name,Fee) values(@Staff_ID,@Staff_Name,@Fee)", con);
                mycmd.Parameters.AddWithValue("@Staff_ID", txtstaffid.Text);
                mycmd.Parameters.AddWithValue("@Staff_Name", txtstaffname.Text);
                mycmd.Parameters.AddWithValue("@Fee", txtfees.Text);
            

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("update Staff set Staff_Name=@Staff_Name,Fee=@Fee where Staff_ID=@Staff_ID", con);
                mycmd.Parameters.AddWithValue("@Staff_ID", txtstaffid.Text);
                mycmd.Parameters.AddWithValue("@Staff_Name", txtstaffname.Text);
                mycmd.Parameters.AddWithValue("@Fee", txtfees.Text);

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("delete from  Staff where  Staff_ID=@Staff_ID and Staff_Name=@Staff_Name and Fee=@Fee", con);
                mycmd.Parameters.AddWithValue("@Staff_ID", txtstaffid.Text);
                mycmd.Parameters.AddWithValue("@Staff_Name", txtstaffname.Text);
                mycmd.Parameters.AddWithValue("@Fee", txtfees.Text);
            

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Succesfully deleted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Can not delete" + ee.Message);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("select * from Staff", con);

                SqlDataAdapter ad = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error");

            }
        }
    }
}
