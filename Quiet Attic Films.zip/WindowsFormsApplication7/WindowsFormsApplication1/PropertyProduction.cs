﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class PropertyProduction : Form
    {
        String con_string = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\quite attic films system\WindowsFormsApplication7\WindowsFormsApplication1\Database2.mdf;Integrated Security=True";
        public PropertyProduction()
        {
            InitializeComponent();
        }

        private void PropertyProduction_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();

                SqlCommand mycmd = new SqlCommand("select Production_ID from Production", con);
                SqlDataReader r = mycmd.ExecuteReader();

                while (r.Read())
                {
                    comboBoxpdid.Items.Add(r["Production_ID"].ToString());
                }
                con.Close();

                con.Open();
                mycmd = new SqlCommand("select Property_ID from Property", con);
                r = mycmd.ExecuteReader();

                while (r.Read())
                {
                    comboBoxprid.Items.Add(r["Property_ID"].ToString());
                }
                con.Close();

                con.Open();
                mycmd = new SqlCommand("select Location_ID from Location", con);
                r = mycmd.ExecuteReader();

                while (r.Read())
                {
                    comboBoxlid.Items.Add(r["Location_ID"].ToString());
                }
                con.Close();


            }
            catch (Exception ee)
            {
                MessageBox.Show("Error" + ee.Message);
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            {
                MainMenu frm = new MainMenu();
                frm.Show();
                this.Hide();
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("insert into Property_Production(Production_ID,Property_ID,No_OF_Days,Location_ID ) values(@Production_ID,@Property_ID,@No_OF_Days,@Location_ID )", con);
                mycmd.Parameters.AddWithValue("@Production_ID", comboBoxpdid.SelectedItem.ToString());
                mycmd.Parameters.AddWithValue("@Property_ID", comboBoxprid.SelectedItem.ToString());
                mycmd.Parameters.AddWithValue("@No_OF_Days", txtnumberofdays.Text);
                mycmd.Parameters.AddWithValue("@Location_ID", comboBoxlid.SelectedItem.ToString());

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Inserted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("update Property_Production set No_OF_Days=@No_OF_Days where Production_ID=@Production_ID and Property_ID=@Property_ID and Location_ID=@Location_ID", con);
                mycmd.Parameters.AddWithValue("@Production_ID", comboBoxpdid.SelectedItem.ToString());
                mycmd.Parameters.AddWithValue("@Property_ID", comboBoxprid.SelectedItem.ToString());
                mycmd.Parameters.AddWithValue("@No_OF_Days", txtnumberofdays.Text);
                mycmd.Parameters.AddWithValue("@Location_ID", comboBoxlid.SelectedItem.ToString());
                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("select * from Property_Production", con);

                SqlDataAdapter ad = new SqlDataAdapter(mycmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Something Went Wrong" + ee.Message);

            }
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(con_string);
                con.Open();
                SqlCommand mycmd = new SqlCommand("Delete from Property_Production where Production_ID=@Production_ID", con);
                mycmd.Parameters.AddWithValue("@Production_ID", comboBoxpdid.SelectedItem.ToString());
                

                mycmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data deleted");
            }
            catch (Exception ee)
            {
                MessageBox.Show("Can not delete");
            }
        }

        private void comboBoxpdid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxprid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxlid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
